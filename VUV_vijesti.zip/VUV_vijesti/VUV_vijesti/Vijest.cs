﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace VUV_vijesti
{
    public class Vijest
    {
        public string Naziv { get; set; }
        public string Opis { get; set; }
        public string Datum { get; set; }
        public string ID { get; set; }
        public Novinar Novinar { get; set; }
        public List<Citatelj> Citatelji { get; set; }
        public List<Komentar> Komentari { get; set; }
        public Vijest(string naziv, string opis, string datum, string iD, Novinar novinar, List<Citatelj> citatelji, List<Komentar> komentari)
        {
            Naziv = naziv;
            Opis = opis;
            Datum = datum;
            ID = iD;
            Novinar = novinar;
            Citatelji = citatelji;
            Komentari = komentari;
        }

        public void DodajCitatelja(Citatelj citatelj)
        {
            Citatelji.Add(citatelj);
        }

        public void DodajKomentar(Komentar komentar)
        {
            Komentari.Add(komentar);
        }
    }
}
