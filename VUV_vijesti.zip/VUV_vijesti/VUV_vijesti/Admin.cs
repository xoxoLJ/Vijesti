﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace VUV_vijesti
{
    public class Admin : Osoba
    {
        public Admin(string ime, string prezime, string korisnicko_ime, string lozinka, string iD) : base(ime, prezime, korisnicko_ime, lozinka, iD) { }
    }
}