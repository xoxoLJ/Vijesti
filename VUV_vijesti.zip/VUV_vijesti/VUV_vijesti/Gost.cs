﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace VUV_vijesti
{
    public class Gost : Osoba
    {
        public Gost(string korisnicko_ime, string iD) : base(korisnicko_ime, iD) { }
    }
}
