﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace VUV_vijesti
{
    public class Komentar
    {
        public string Opis { get; set; }
        public string Datum { get; set; }
        public string ID { get; set; }
        public Citatelj Citatelj { get; set; }
        public Komentar(string opis, string datum, string iD, Citatelj citatelj)
        {
            Opis = opis;
            Datum = datum;
            ID = iD;
            Citatelj = citatelj;
        }
    }
}
