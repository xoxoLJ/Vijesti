﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace VUV_vijesti
{
    public class Citatelj : Osoba
    {
        public Citatelj(string ime, string prezime, string korisnicko_ime, string lozinka, string iD) : base(ime, prezime, korisnicko_ime, lozinka, iD) { }

        public void KomentirajVijest(Vijest vijest, string opis)
        {
            Komentar komentar = new Komentar(opis, "19.06.2023", ID, this);

            vijest.DodajKomentar(komentar);
        }
    }
}
