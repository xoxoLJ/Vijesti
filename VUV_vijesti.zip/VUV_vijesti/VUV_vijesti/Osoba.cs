﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace VUV_vijesti
{
    public abstract class Osoba
    {
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string Korisnicko_Ime { get; set; }
        public string Lozinka { get; set; }
        public string ID { get; set; }
        public Osoba(string korisnicko_ime, string id)
        {
            Korisnicko_Ime = korisnicko_ime;
            ID = id;
        }
        public Osoba(string ime, string prezime, string korisnicko_ime, string lozinka, string iD)
        {
            Ime = ime;
            Prezime = prezime;
            Korisnicko_Ime= korisnicko_ime;
            Lozinka = lozinka;
            ID= iD;
        }
    }
}
