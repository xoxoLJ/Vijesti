﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace VUV_vijesti
{
    class MojeIznimke : Exception
    {
        public MojeIznimke() { }
        public MojeIznimke(string poruka) : base(poruka)
        {
            Console.WriteLine("Korisnicka poruka kreirana!");
        }
        public MojeIznimke(string poruka, Exception unutarnja) : base(poruka, unutarnja)
        {
            Console.WriteLine("Korisnicka poruka kreirana!");
        }
    }

    class Program
    {
        static XmlDocument xmlDoc = new XmlDocument();

        static List<Admin> ladmini = new List<Admin>();
        static List<Citatelj> lcitatelji = new List<Citatelj>();
        static List<Novinar> lnovinari = new List<Novinar>();
        static List<Komentar> lkomentari = new List<Komentar>();
        static List<Vijest> lvijesti = new List<Vijest>();

        static string login;
        static Gost gost = new Gost(login, "01");

        static void Main(string[] args)
        {
            try
            {
                InicijalizirajPodatke();

                bool izlaz = true;

                while (izlaz)
                {
                    Console.WriteLine("Molim odaberite opciju za login:");
                    Console.WriteLine("\t1 - Administrator");
                    Console.WriteLine("\t2 - Novinar");
                    Console.WriteLine("\t3 - Citatelj");
                    Console.WriteLine("\t4 - Gost");
                    Console.WriteLine("\t5 - Izlaz");

                    string unos = Console.ReadLine();
                    switch (unos)
                    {
                        case "1":
                            Console.WriteLine("Unesite korisnicko ime i lozinku za admina:");
                            for (int i = 1; i <= 3; i++)
                            {
                                string ai = Console.ReadLine();
                                string al = Console.ReadLine();
                                foreach (Admin a in ladmini)
                                {
                                    if (ai == a.Korisnicko_Ime && al == a.Lozinka)
                                    {
                                        login = ai;
                                        GlavniIzbornik();
                                        break;
                                    }
                                }
                                if(login != null)
                                {
                                    break;
                                }
                                Console.WriteLine("Krivi unos. Pokusajte ponovno.");
                            }
                            if (login != null)
                            {
                                login = null;
                                break;
                            }
                            Console.WriteLine("Previse pokusaja pri logiranju!");
                            break;
                        case "2":
                            Console.WriteLine("Unesite korisnicko ime i lozinku za novinara:");
                            for (int i = 1; i <= 3; i++)
                            {
                                string ni = Console.ReadLine();
                                string nl = Console.ReadLine();
                                foreach (Novinar n in lnovinari)
                                {
                                    if (ni == n.Korisnicko_Ime && nl == n.Lozinka)
                                    {
                                        login = ni;
                                        GlavniIzbornik();
                                        break;
                                    }
                                }
                                if (login != null)
                                {
                                    break;
                                }
                                Console.WriteLine("Krivi unos. Pokusajte ponovno.");
                            }
                            if (login != null)
                            {
                                login = null;
                                break;
                            }
                            Console.WriteLine("Previse pokusaja pri logiranju!");
                            break;
                        case "3":
                            Console.WriteLine("Unesite korisnicko ime i lozinku za citatelja: ");
                            for (int i = 1; i <= 3; i++)
                            {
                                string ci = Console.ReadLine();
                                string cl = Console.ReadLine();
                                foreach (Citatelj c in lcitatelji)
                                {
                                    if (ci == c.Korisnicko_Ime && cl == c.Lozinka)
                                    {
                                        login = ci;
                                        GlavniIzbornik();
                                        break;
                                    }
                                }
                                if (login != null)
                                {
                                    break;
                                }
                                Console.WriteLine("Krivi unos. Pokusajte ponovno.");
                            }
                            if (login != null)
                            {
                                login = null;
                                break;
                            }
                            Console.WriteLine("Previse pokusaja pri logiranju!");
                            break;
                        case "4":
                            Console.WriteLine("Ulogirani ste kao gost");
                            login = "gost";
                            Gost g = new Gost(login, "01");
                            GlavniIzbornik();
                            login = null;
                            break;
                        case "5":
                            izlaz = false;
                            Console.WriteLine("Uspješno ste izašli iz programa.");
                            break;
                        default:
                            Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                            break;
                    }
                    Console.WriteLine();
                }
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u main-u: " + e.Message);
            }
        }
        static void InicijalizirajPodatke()
        {
            try
            {
                string xml = "";
                StreamReader sr = new StreamReader("C://Users/Komp/Desktop/Projekti/2. Semestar/VUV_vijesti/VUV_vijesti/VUV_vijesti.xml");
                using (sr)
                {
                    xml = sr.ReadToEnd();
                }
                xmlDoc.LoadXml(xml);

                XmlNodeList adminiXml = xmlDoc.SelectNodes("/VUV_vijesti/Admini/Admin");
                foreach(XmlNode ad in adminiXml)
                {
                    ladmini.Add(new Admin(ad.Attributes["Ime"].Value, ad.Attributes["Prezime"].Value, ad.Attributes["Korisnicko_Ime"].Value, ad.Attributes["Lozinka"].Value, ad.Attributes["ID"].Value));
                }

                XmlNodeList citateljiXml = xmlDoc.SelectNodes("/VUV_vijesti/Citatelji/Citatelj");
                foreach (XmlNode ct in citateljiXml)
                {
                    lcitatelji.Add(new Citatelj(ct.Attributes["Ime"].Value, ct.Attributes["Prezime"].Value, ct.Attributes["Korisnicko_Ime"].Value, ct.Attributes["Lozinka"].Value, ct.Attributes["ID"].Value));
                }

                XmlNodeList novinariXml = xmlDoc.SelectNodes("/VUV_vijesti/Novinari/Novinar");
                foreach (XmlNode nv in novinariXml)
                {
                    lnovinari.Add(new Novinar(nv.Attributes["Ime"].Value, nv.Attributes["Prezime"].Value, nv.Attributes["Korisnicko_Ime"].Value, nv.Attributes["Lozinka"].Value, nv.Attributes["ID"].Value));
                }

                XmlNodeList komentariXml = xmlDoc.SelectNodes("/VUV_vijesti/Komentari/Komentar");
                foreach (XmlNode km in komentariXml)
                {
                    Citatelj c = PronadiCitatelja(lcitatelji, km.FirstChild.Attributes["ID"].Value);
                    lkomentari.Add(new Komentar(km.Attributes["Opis"].Value, km.Attributes["Datum"].Value, km.Attributes["ID"].Value, c));
                }

                XmlNodeList vijestiXml = xmlDoc.SelectNodes("/VUV_vijesti/Vijesti/Vijest");
                foreach (XmlNode vj in vijestiXml)
                {
                    Novinar n = PronadiNovinara(lnovinari, vj.FirstChild.Attributes["ID"].Value);
                    List<Citatelj> lc = new List<Citatelj>();
                    for (XmlNode i = vj.FirstChild.NextSibling.FirstChild; i != null; i = i.NextSibling)
                    {
                        lc.Add(PronadiCitatelja(lcitatelji, i.Attributes["ID"].Value));
                    }
                    List<Komentar> lk = new List<Komentar>();
                    for (XmlNode i = vj.LastChild.FirstChild; i != null; i = i.NextSibling)
                    {
                        lk.Add(PronadiKomentar(lkomentari, i.Attributes["ID"].Value));
                    }
                    lvijesti.Add(new Vijest(vj.Attributes["Naziv"].Value, vj.Attributes["Opis"].Value, vj.Attributes["Datum"].Value, vj.Attributes["ID"].Value, n, lc, lk));
                }
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u IniciajlizirajPodatke(): " + e.Message);
            }
        }
        static Admin PronadiAdmina(List<Admin> lad, string id)
        {
            foreach (Admin ad in lad)
            {
                if (ad.ID == id)
                {
                    return ad;
                }
            }
            return null;
        }
        static Citatelj PronadiCitatelja(List<Citatelj> lct, string id)
        {
            foreach (Citatelj ct in lct)
            {
                if (ct.ID == id)
                {
                    return ct;
                }
            }
            return null;
        }
        static Novinar PronadiNovinara(List<Novinar> lnv, string id)
        {
            foreach (Novinar nv in lnv)
            {
                if (nv.ID == id)
                {
                    return nv;
                }
            }
            return null;
        }
        static Komentar PronadiKomentar(List<Komentar> lkm, string id)
        {
            foreach (Komentar km in lkm)
            {
                if (km.ID == id)
                {
                    return km;
                }
            }
            return null;
        }
        static Vijest PronadiVijest(List<Vijest> lvj, string id)
        {
            foreach (Vijest vj in lvj)
            {
                if (vj.ID == id)
                {
                    return vj;
                }
            }
            return null;
        }
        static Osoba VrstaLogin()
        {
            foreach (Admin a in ladmini)
            {
                if (a.Korisnicko_Ime == login)
                {
                    return a;
                }
            }
            foreach (Novinar n in lnovinari)
            {
                if (n.Korisnicko_Ime == login)
                {
                    return n;
                }
            }
            foreach (Citatelj c in lcitatelji)
            {
                if (c.Korisnicko_Ime == login)
                {
                    return c;
                }
            }
            if (login == "gost")
            {
                return gost;
            }
            return null;
        }

        static void SpremanjeVijesti()
        {
            try
            {
                XmlNode vijestiNode = xmlDoc.SelectSingleNode("/VUV_vijesti/Vijesti");
                vijestiNode.RemoveAll();

                foreach (Vijest vijest in lvijesti)
                {
                    Console.WriteLine("Spremanje vijesti naziva: " + vijest.Naziv);

                    XmlNode noviNode = xmlDoc.CreateNode(XmlNodeType.Element, "Vijest", null);

                    XmlAttribute nazivAttr = xmlDoc.CreateAttribute("Naziv");
                    nazivAttr.Value = vijest.Naziv;
                    noviNode.Attributes.Append(nazivAttr);

                    XmlAttribute opisAttr = xmlDoc.CreateAttribute("Opis");
                    opisAttr.Value = vijest.Opis;
                    noviNode.Attributes.Append(opisAttr);

                    XmlAttribute datumAttr = xmlDoc.CreateAttribute("Datum");
                    datumAttr.Value = vijest.Datum;
                    noviNode.Attributes.Append(datumAttr);

                    XmlAttribute idAttr = xmlDoc.CreateAttribute("ID");
                    idAttr.Value = vijest.ID;
                    noviNode.Attributes.Append(idAttr);

                    XmlNode novinarNode = xmlDoc.CreateNode(XmlNodeType.Element, "Novinar", null);
                    noviNode.AppendChild(novinarNode);

                    XmlAttribute novinarIDAttr = xmlDoc.CreateAttribute("ID");
                    novinarIDAttr.Value = vijest.Novinar.ID;
                    novinarNode.Attributes.Append(novinarIDAttr);

                    XmlNode citateljiNode = xmlDoc.CreateNode(XmlNodeType.Element, "Citatelji", null);
                    noviNode.AppendChild(citateljiNode);


                    if (vijest.Citatelji.Count == 0)
                    {
                    }
                    else
                    {
                        foreach (Citatelj citatelj in vijest.Citatelji)
                        {
                            XmlNode citateljNode = xmlDoc.CreateNode(XmlNodeType.Element, "Citatelj", null);
                            XmlAttribute citateljIDAttr = xmlDoc.CreateAttribute("ID");
                            citateljIDAttr.Value = citatelj.ID;
                            citateljNode.Attributes.Append(citateljIDAttr);
                            citateljiNode.AppendChild(citateljNode);
                        }
                    }

                    XmlNode komentariNode = xmlDoc.CreateNode(XmlNodeType.Element, "Komentari", null);
                    noviNode.AppendChild(komentariNode);
                    if (vijest.Komentari.Count == 0)
                    {
                    }
                    else
                    {
                        foreach (Komentar komentar in vijest.Komentari)
                        {
                            XmlNode komentarNode = xmlDoc.CreateNode(XmlNodeType.Element, "Komentar", null);
                            XmlAttribute komentarIDAttr = xmlDoc.CreateAttribute("ID");
                            komentarIDAttr.Value = komentar.ID;
                            komentarNode.Attributes.Append(komentarIDAttr);
                            komentariNode.AppendChild(komentarNode);
                        }
                    }
                    vijestiNode.AppendChild(noviNode);
                }

                xmlDoc.Save("C://Users/Komp/Desktop/Projekti/2. Semestar/VUV_vijesti/VUV_vijesti/VUV_vijesti.xml");
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u IniciajlizirajPodatke(): " + e.Message);
            }
        }
        static void GlavniIzbornik()
        {
            try
            {
                foreach (Admin admin in ladmini)
                {
                    if (login == admin.Korisnicko_Ime)
                    {
                        bool aizlaz = true;
                        while (aizlaz)
                        {
                            Console.WriteLine("Odaberite opciju:");
                            Console.WriteLine("\t1 - Pregled vijesti");
                            Console.WriteLine("\t2 - Dodavanje/Brisanje/Ažuriranje vijesti");
                            Console.WriteLine("\t3 - Tražilica vijesti prema unesenom pojmu");
                            Console.WriteLine("\t4 - Dodavanje novinara");
                            Console.WriteLine("\t5 - Brisanje novinara");
                            Console.WriteLine("\t6 - Izlaz");

                            string unos = Console.ReadLine();
                            switch (unos)
                            {
                                case "1":
                                    PregledVijesti();
                                    break;
                                case "2":
                                    IzbornikVijesti();
                                    break;
                                case "3":
                                    TraziVijesti();
                                    break;
                                case "4":
                                    DodajNovinara();
                                    break;
                                case "5":
                                    IzbrisiNovinara();
                                    break;
                                case "6":
                                    aizlaz = false;
                                    Console.WriteLine("Uspješno ste izlogirani.");
                                    break;
                                default:
                                    Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                                    break;
                            }

                            Console.WriteLine();
                        }
                    }
                }
                foreach (Novinar novinar in lnovinari)
                {
                    if (login == novinar.Korisnicko_Ime)
                    {
                        bool nizlaz = true;
                        while (nizlaz)
                        {
                            Console.WriteLine("Odaberite opciju:");
                            Console.WriteLine("\t1 - Pregled vijesti");
                            Console.WriteLine("\t2 - Dodavanje/Brisanje/Ažuriranje vijesti");
                            Console.WriteLine("\t3 - Tražilica vijesti prema unesenom pojmu");
                            Console.WriteLine("\t4 - Izlaz");

                            string unos = Console.ReadLine();
                            switch (unos)
                            {
                                case "1":
                                    PregledVijesti();
                                    break;
                                case "2":
                                    IzbornikVijesti();
                                    break;
                                case "3":
                                    TraziVijesti();
                                    break;
                                case "4":
                                    nizlaz = false;
                                    Console.WriteLine("Uspješno ste izlogirani.");
                                    break;
                                default:
                                    Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                                    break;
                            }

                            Console.WriteLine();
                        }
                    }
                }
                foreach (Citatelj citatelj in lcitatelji)
                {
                    if (login == citatelj.Korisnicko_Ime)
                    {
                        bool cizlaz = true;
                        while (cizlaz)
                        {
                            Console.WriteLine("Odaberite opciju:");
                            Console.WriteLine("\t1 - Pregled vijesti");
                            Console.WriteLine("\t2 - Tražilica vijesti prema unesenom pojmu");
                            Console.WriteLine("\t3 - Izlaz");

                            string unos = Console.ReadLine();
                            switch (unos)
                            {
                                case "1":
                                    PregledVijesti();
                                    break;
                                case "2":
                                    TraziVijesti();
                                    break;
                                case "3":
                                    cizlaz = false;
                                    Console.WriteLine("Uspješno ste izlogirani.");
                                    break;
                                default:
                                    Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                                    break;
                            }

                            Console.WriteLine();
                        }
                    }
                }
                if (login == "gost")
                {
                    bool izlaz = true;
                    while (izlaz)
                    {
                        Console.WriteLine("Odaberite opciju:");
                        Console.WriteLine("\t1 - Pregled vijesti");
                        Console.WriteLine("\t2 - Tražilica vijesti prema unesenom pojmu");
                        Console.WriteLine("\t3 - Izlaz");

                        string unos = Console.ReadLine();
                        switch (unos)
                        {
                            case "1":
                                PregledVijesti();
                                break;
                            case "2":
                                TraziVijesti();
                                break;
                            case "3":
                                izlaz = false;
                                Console.WriteLine("Uspješno ste izlogirani.");
                                break;
                            default:
                                Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                                break;
                        }
                    }
                }
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u GlavniIzbornik(): " + e.Message);
            }
        }
        static void PregledVijesti()
        {
            try
            {
                Console.WriteLine("Sve dostupne vijesti:");
                int i = 0;
                foreach (Vijest vijest in lvijesti)
                {
                    i++;
                    Console.WriteLine("\t" + i + ". " + vijest.Naziv);
                }

                Console.WriteLine();
                Console.WriteLine("Odaberite redni broj vijesti koju želite odabrati ili unesite 'i' za povratak na izbornik.");

                string unos = Console.ReadLine();
                if (unos == "i")
                {
                    return;
                }

                if (int.TryParse(unos, out int index) && index > 0 && index <= lvijesti.Count)
                {
                    PrikaziVijest(lvijesti[index - 1]);
                }
                else
                {
                    Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                }
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u PregledVijesti(): " + e.Message);
            }
        }

        static void PrikaziVijest(Vijest vijest)
        {
            try
            {
                Console.WriteLine();
                Vijest v = PronadiVijest(lvijesti, vijest.ID);
                Console.WriteLine("Naziv vijesti: " + v.Naziv);
                Console.WriteLine("Opis: " + v.Opis);
                Console.WriteLine("Datum: " + v.Datum);

                Novinar n = PronadiNovinara(lnovinari, v.Novinar.ID);

                Console.WriteLine("Novinar: " + n.Ime + " " + n.Prezime);
                Console.WriteLine();

                if (v.Citatelji.Count == 0)
                {
                    Console.WriteLine("Vijest nema citatelja.");
                }
                else
                {
                    Console.WriteLine("Citatelji vijesti:");
                    foreach (Citatelj citatelj in v.Citatelji)
                    {
                        Citatelj c = PronadiCitatelja(lcitatelji, citatelj.ID);

                        Console.WriteLine("\tKorisnicko ime: " + c.Korisnicko_Ime);
                        Console.WriteLine();
                    }
                }

                if (v.Komentari.Count == 0)
                {
                    Console.WriteLine("Vijest nema komentara.");
                }
                else
                {
                    Console.WriteLine("Komentari vijesti:");
                    foreach (Komentar komentar in v.Komentari)
                    {
                        Komentar k = PronadiKomentar(lkomentari, komentar.ID);
                        Citatelj c = PronadiCitatelja(lcitatelji, k.Citatelj.ID);

                        Console.WriteLine("\tAutor komentara: " + c.Korisnicko_Ime);
                        Console.WriteLine("\tOpis: " + k.Opis);
                        Console.WriteLine("\tDatum: " + k.Datum);
                        Console.WriteLine();
                    }
                }

                foreach (Citatelj citatelj in lcitatelji)
                {
                    if (login == citatelj.Korisnicko_Ime)
                    {
                        Console.WriteLine("Odaberite želite li dodati novi komentar");
                        Console.WriteLine("\t1 - Dodaj komentar");
                        Console.WriteLine("\t2 - Povratak na izbornik");
                        string unos = Console.ReadLine();
                        switch (unos)
                        {
                            case "1":
                                Console.WriteLine("Napišite opis komentara:");
                                string opis = Console.ReadLine();
                                citatelj.KomentirajVijest(v, opis);
                                break;
                            case "2":
                                break;
                            default:
                                Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                                break;
                        }
                    }
                }
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u PrikaziVijest(): " + e.Message);
            }
        }
        static void IzbornikVijesti()
        {
            try
            {
                foreach(Admin a in ladmini)
                {
                    if (login == a.Korisnicko_Ime)
                    {
                        bool izlaz = true;
                        while (izlaz)
                        {
                            Console.WriteLine("Odaberite opciju:");
                            Console.WriteLine("\t1 - Brisanje vijesti");
                            Console.WriteLine("\t2 - Povratak na izbornik");

                            string unos = Console.ReadLine();
                            switch (unos)
                            {
                                case "1":
                                    IzbrisiVijest();
                                    break;
                                case "2":
                                    izlaz = false;
                                    break;
                                default:
                                    Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                                    break;
                            }

                            Console.WriteLine();
                        }
                    }
                }
                foreach (Novinar n in lnovinari)
                {
                    if (login == n.Korisnicko_Ime)
                    {
                        bool izlaz = true;
                        while (izlaz)
                        {
                            Console.WriteLine("Odaberite opciju:");
                            Console.WriteLine("\t1 - Dodavanje vijesti");
                            Console.WriteLine("\t2 - Brisanje vijesti");
                            Console.WriteLine("\t3 - Ažuriranje vijesti");
                            Console.WriteLine("\t4 - Povratak na izbornik");

                            string unos = Console.ReadLine();
                            switch (unos)
                            {
                                case "1":
                                    DodajVijest();
                                    break;
                                case "2":
                                    IzbrisiVijest();
                                    break;
                                case "3":
                                    AzurirajVijest();
                                    break;
                                case "4":
                                    izlaz = false;
                                    break;
                                default:
                                    Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                                    break;
                            }

                            Console.WriteLine();
                        }
                    }
                }
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u IzbornikVijesti(): " + e.Message);
            }
        }
        static void DodajVijest()
        {
            try
            {
                Console.WriteLine("Unesite naziv nove vijesti:");
                string naziv = Console.ReadLine();

                Console.WriteLine("Unesite opis nove vijesti:");
                string opis = Console.ReadLine();

                /*Console.WriteLine("Odaberite redni broj novinara ili unesite 'n' za unos novog novinara:");
                for (int i = 0; i < lnovinari.Count; i++)
                {
                    Console.WriteLine(i + 1 + ". " + lnovinari[i].Ime + " " + lnovinari[i].Prezime);
                }
                Console.WriteLine("n. Unos novog novinara");*/

                List<Citatelj> lct = new List<Citatelj>();
                List<Komentar> lkm = new List<Komentar>();

                foreach (Novinar novinar in lnovinari)
                {
                    if (login == novinar.Korisnicko_Ime)
                    {
                        Vijest novaVijest = new Vijest(naziv, opis, "09.06.2023.", "23", novinar, lct, lkm);
                        lvijesti.Add(novaVijest);
                    }
                }

                SpremanjeVijesti();

                Console.WriteLine("Vijest uspješno dodana.");

            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u DodajVijest(): " + e.Message);
            }
        }

        static void IzbrisiVijest()
        {
            try
            {
                foreach(Admin admin in ladmini)
                {
                    if (login == admin.Korisnicko_Ime)
                    {
                        Console.WriteLine("Dostupne vijesti za brisanje:");
                        for (int i = 0; i < lvijesti.Count; i++)
                        {
                            Console.WriteLine(i + 1 + ". " + lvijesti[i].Naziv);
                        }
                        Console.WriteLine();
                        Console.WriteLine("Odaberite vijest za brisanje (broj) ili unesite 'i' za povratak na izbornik.");
                        string unos = Console.ReadLine();
                        if (unos == "i")
                        {
                            return;
                        }
                        if (int.TryParse(unos, out int index) && index > 0 && index <= lvijesti.Count)
                        {
                            lvijesti.Remove(lvijesti[index - 1]);

                            SpremanjeVijesti();

                            Console.WriteLine("Vijest uspješno obrisana.");
                        }
                        else
                        {
                            Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                        }
                    }
                }
                foreach(Novinar novinar in lnovinari)
                {
                    if (login == novinar.Korisnicko_Ime)
                    {
                        List<Vijest> lvijestinovinara = new List<Vijest>();
                        Console.WriteLine("Dostupne vijesti za brisanje:");
                        int i = 0;
                        foreach (Vijest vijest in lvijesti)
                        {
                            if (vijest.Novinar.ID == novinar.ID)
                            {
                                i++;
                                lvijestinovinara.Add(vijest);
                                Console.WriteLine(i + ". " + lvijestinovinara[i-1].Naziv);
                            }
                        }
                        Console.WriteLine();
                        Console.WriteLine("Odaberite vijest za brisanje (broj) ili unesite 'i' za povratak na izbornik.");

                        string unosn = Console.ReadLine();
                        if (unosn == "i")
                        {
                            return;
                        }
                        if (int.TryParse(unosn, out int indexn) && indexn > 0 && indexn <= lvijestinovinara.Count)
                        {
                            lvijesti.Remove(lvijestinovinara[indexn - 1]);

                            SpremanjeVijesti();

                            Console.WriteLine("Vijest uspješno obrisana.");
                        }
                        else
                        {
                            Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                        }
                    }
                }
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u IzbrisiVijest(): " + e.Message);
            }
        }

        static void AzurirajVijest()
        {
            try
            {
                foreach(Novinar novinar in lnovinari)
                {
                    if (login == novinar.Korisnicko_Ime)
                    {
                        List<Vijest> lvijestinovinara = new List<Vijest>();
                        Console.WriteLine("Dostupne vijesti za ažuriranje:");
                        int i = 0;
                        foreach (Vijest vijest in lvijesti)
                        {
                            if (vijest.Novinar.ID == novinar.ID)
                            {
                                i++;
                                lvijestinovinara.Add(vijest);
                                Console.WriteLine(i + ". " + lvijestinovinara[i - 1].Naziv);
                            }
                        }
                        Console.WriteLine();
                        Console.WriteLine("Odaberite vijest za ažuriranje (broj) ili unesite 'i' za povratak na izbornik.");

                        string unos = Console.ReadLine();
                        if (unos == "i")
                        {
                            return;
                        }
                        if (int.TryParse(unos, out int index) && index > 0 && index <= lvijestinovinara.Count)
                        {
                            Vijest vijest = lvijestinovinara[index - 1];

                            Console.Write("Trenutni naziv vijesti: ");
                            Console.WriteLine(vijest.Naziv);
                            Console.WriteLine("Unesite novi naziv vijesti:");
                            vijest.Naziv = Console.ReadLine();

                            if (vijest.Naziv == "")
                            {
                                throw new Exception("Unesen je neispravan naziv za vijest!");
                            }

                            Console.Write("Trenutni opis vijesti: ");
                            Console.WriteLine(vijest.Opis);
                            Console.WriteLine("Unesite novi opis vijesti:");
                            vijest.Opis = Console.ReadLine();

                            if (vijest.Opis == "")
                            {
                                throw new Exception("Unesen je neispravan naziv za vijest!");
                            }

                            foreach(Vijest v in lvijesti)
                            {
                                foreach(Vijest vn in lvijestinovinara)
                                {
                                    if(v.ID == vn.ID)
                                    {
                                        v.Naziv = vn.Naziv;
                                        v.Opis = vn.Opis;
                                    }
                                }
                            }

                            SpremanjeVijesti();
                        }
                        else
                        {
                            Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                        }
                    }
                }
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u AzurirajVijest(): " + e.Message);
            }
        }
        static void TraziVijesti()
        {
            try
            {
                Console.WriteLine("Unesite pojam za pretraživanje vijesti:");
                string pojam = Console.ReadLine();
                List<Vijest> rezultatiPretrage = new List<Vijest>();

                foreach (Vijest v in lvijesti)
                {
                    if (v.Naziv.ToLower().Contains(pojam.ToLower()) || v.Opis.ToLower().Contains(pojam.ToLower()))
                    {
                        rezultatiPretrage.Add(v);
                    }
                }

                if (rezultatiPretrage.Count == 0)
                {
                    Console.WriteLine("Nema rezultata za uneseni pojam.");
                }
                else
                {
                    Console.WriteLine("Rezultati pretrage za pojam {0}:", pojam);
                    for (int i = 0; i < rezultatiPretrage.Count; i++)
                    {
                        Console.WriteLine(i + 1 + ". " + rezultatiPretrage[i].Naziv);
                    }

                    Console.WriteLine();
                    Console.WriteLine("Odaberite vijest (broj) ili unesite 'i' za povratak na izbornik.");

                    string unos = Console.ReadLine();
                    if (unos == "i")
                    {
                        return;
                    }

                    if (int.TryParse(unos, out int index) && index > 0 && index <= rezultatiPretrage.Count)
                    {
                        PrikaziVijestISveKomentare(rezultatiPretrage[index - 1]);
                    }
                    else
                    {
                        Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                    }
                }
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u TraziVijest(): " + e.Message);
            }
        }
        static void PrikaziVijestISveKomentare(Vijest vijest)
        {
            try
            {
                Console.WriteLine();
                Vijest v = PronadiVijest(lvijesti, vijest.ID);
                Console.WriteLine("Naziv vijesti: " + v.Naziv);
                Console.WriteLine("Opis: " + v.Opis);
                Console.WriteLine("Datum: " + v.Datum);

                Novinar n = PronadiNovinara(lnovinari, v.Novinar.ID);

                Console.WriteLine("Novinar: " + n.Ime + " " + n.Prezime);
                Console.WriteLine();

                if (v.Citatelji.Count == 0)
                {
                    Console.WriteLine("Vijest nema citatelja.");
                }
                else
                {
                    Console.WriteLine("Citatelji vijesti:");
                    foreach (Citatelj citatelj in v.Citatelji)
                    {
                        Citatelj c = PronadiCitatelja(lcitatelji, citatelj.ID);

                        Console.WriteLine("\tKorisnicko ime: " + c.Korisnicko_Ime);
                        Console.WriteLine();
                    }
                }

                if (v.Komentari.Count == 0)
                {
                    Console.WriteLine("Vijest nema komentara.");
                }
                else
                {
                    Console.WriteLine("Komentari vijesti:");
                    foreach (Komentar komentar in v.Komentari)
                    {
                        Komentar k = PronadiKomentar(lkomentari, komentar.ID);
                        Citatelj c = PronadiCitatelja(lcitatelji, k.Citatelj.ID);

                        Console.WriteLine("\tAutor komentara: " + c.Korisnicko_Ime);
                        Console.WriteLine("\tOpis: " + k.Opis);
                        Console.WriteLine("\tDatum: " + k.Datum);
                        Console.WriteLine();
                    }
                }

                foreach (Citatelj citatelj in lcitatelji)
                {
                    if (login == citatelj.Korisnicko_Ime)
                    {
                        Console.WriteLine("Odaberite želite li dodati novi komentar");
                        Console.WriteLine("\t1 - Dodaj komentar");
                        Console.WriteLine("\t2 - Povratak na izbornik");
                        string unos = Console.ReadLine();
                        switch (unos)
                        {
                            case "1":
                                Console.WriteLine("Napišite opis komentara:");
                                string opis = Console.ReadLine();
                                citatelj.KomentirajVijest(v, opis);
                                break;
                            case "2":
                                break;
                            default:
                                Console.WriteLine("Nevažeći unos. Pokušajte ponovno.");
                                break;
                        }
                    }
                }
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u PrikaziVijestiISveKomentare(): " + e.Message);
            }
        }
        static void DodajNovinara()
        {
            try
            {
                Console.WriteLine("Unesite ime novog novinara:");
                string ime = Console.ReadLine();

                if (ime == "")
                {
                    throw new MojeIznimke("Nije uneseno ime");
                }

                Console.WriteLine("Unesite prezime novog novinara:");
                string prezime = Console.ReadLine();

                if (prezime == "")
                {
                    throw new MojeIznimke("Nije uneseno prezime");
                }

                Console.WriteLine("Unesite korisnicko_ime novog novinara:");
                string korisnicko_ime = Console.ReadLine();

                foreach (Novinar n in lnovinari)
                {
                    if (korisnicko_ime == "")
                    {
                        throw new MojeIznimke("Nije uneseno korisničko ime");
                    }
                    if (korisnicko_ime == n.Korisnicko_Ime)
                    {
                        throw new MojeIznimke("Korisnicko ime već postoji");
                    }
                }

                Console.WriteLine("Unesite lozinku novog novinara:");
                string lozinka = Console.ReadLine();

                if (lozinka == "")
                {
                    throw new MojeIznimke("Nije unesena lozinka");
                }

                Console.WriteLine("Unesite id novinara:");
                string id = Console.ReadLine();

                foreach (Novinar n in lnovinari)
                {
                    if (id == "")
                    {
                        throw new MojeIznimke("Nije unesen dobar ID");
                    }
                    if (id == n.ID)
                    {
                        throw new MojeIznimke("ID već postoji");
                    }
                }

                Novinar novinar = new Novinar(ime, prezime, korisnicko_ime, lozinka, id);

                DodajNovinaraUXML(novinar);

                Console.WriteLine("Novinar uspješno dodan.");
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u DodajNovinara(): " + e.Message);
            }
        }

        static void IzbrisiNovinara()
        {
            try
            {
                Console.WriteLine("Unesite ID novinara za brisanje:");
                foreach(Novinar n in lnovinari)
                {
                    Console.WriteLine("Novinar: " + n.Korisnicko_Ime + " sa ID: " + n.ID);
                }
                string id = Console.ReadLine();

                Novinar novinar = PronadiNovinara(lnovinari, id);

                if (novinar == null)
                {
                    Console.WriteLine("Novinar s unesenim ID-om ne postoji.");
                }
                else if (NovinarImaVijesti(novinar))
                {
                    Console.WriteLine("Novinara nije moguće obrisati jer ima pripadajuće vijesti.");
                }
                else
                {
                    IzbrisiNovinaraIzXML(novinar);

                    Console.WriteLine("Novinar uspješno obrisan.");
                }
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u IzbrisiNovinara(): " + e.Message);
            }
        }

        static bool NovinarImaVijesti(Novinar novinar)
        {
            foreach (Vijest v in lvijesti)
            {
                if (v.Novinar == novinar)
                {
                    return true;
                }
            }
            return false;
        }

        static void DodajNovinaraUXML(Novinar novinar)
        {
            try
            {
                lnovinari.Add(novinar);

                SpremiNovinareUXML(lnovinari);
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u DodajNovinaraUXML: " + e.Message);
            }
        }

        static void IzbrisiNovinaraIzXML(Novinar novinar)
        {
            try
            {
                lnovinari.Remove(novinar);

                lnovinari.Add(new Novinar("deleted", "deleted", "deleted", "deleted", "deleted"));

                SpremiNovinareUXML(lnovinari);
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u IzbrisiNovinaraIzXML: " + e.Message);
            }
        }
        static void SpremiNovinareUXML(List<Novinar> novinari)
        {
            try
            {
                XmlNode novinariNode = xmlDoc.SelectSingleNode("/VUV_vijesti/Novinari");
                novinariNode.RemoveAll();

                foreach (Novinar novinar in lnovinari)
                {
                    XmlNode noviNode = xmlDoc.CreateNode(XmlNodeType.Element, "Novinar", null);

                    XmlAttribute imeAttr = xmlDoc.CreateAttribute("Ime");
                    imeAttr.Value = novinar.Ime;
                    noviNode.Attributes.Append(imeAttr);

                    XmlAttribute prezimeAttr = xmlDoc.CreateAttribute("Prezime");
                    prezimeAttr.Value = novinar.Prezime;
                    noviNode.Attributes.Append(prezimeAttr);

                    XmlAttribute korisnickoimeAttr = xmlDoc.CreateAttribute("Korisnicko_Ime");
                    korisnickoimeAttr.Value = novinar.Korisnicko_Ime;
                    noviNode.Attributes.Append(korisnickoimeAttr);

                    XmlAttribute lozinkaAttr = xmlDoc.CreateAttribute("Lozinka");
                    lozinkaAttr.Value = novinar.Lozinka;
                    noviNode.Attributes.Append(lozinkaAttr);

                    XmlAttribute idAttr = xmlDoc.CreateAttribute("ID");
                    idAttr.Value = novinar.ID;
                    noviNode.Attributes.Append(idAttr);
                }
                xmlDoc.Save("VUV_vijesti.xml");
            }
            catch (MojeIznimke e)
            {
                Console.WriteLine("Došlo je do ove greške u SpremiNovinareUXML: " + e.Message);
            }
        }
    }
}